# Pulse Watch

An application that helps to export Fitbit heart rate data.
